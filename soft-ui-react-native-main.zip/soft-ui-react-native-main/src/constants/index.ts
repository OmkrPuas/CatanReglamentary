export {default as mocks} from './mocks';
export {THEME as light} from './light';
